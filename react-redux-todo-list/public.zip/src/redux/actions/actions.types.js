export const ADD_COUNTER = "ADD_COUNTER";
export const MINUS_COUNTER = "MINUS_COUNTER"
export const RESET_COUNTER = "RESET_COUNTER";
export const ADD_TODO = "ADD_TODO";
export const CLEAR_TODO_LIST = "CLEAR_TODO_LIST";
export const DELETE_TODO = "DELETE_TODO";
export const TOGGLE_TODO = "TOGGLE_TODO";

